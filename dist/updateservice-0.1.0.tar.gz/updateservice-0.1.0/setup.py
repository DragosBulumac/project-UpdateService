# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['updateservice',
 'updateservice.api_tests',
 'updateservice.apis',
 'updateservice.models',
 'updateservice.repositories',
 'updateservice.services',
 'updateservice.tests']

package_data = \
{'': ['*']}

install_requires = \
['coverage>=6.5.0,<7.0.0',
 'django>=4.1.3,<5.0.0',
 'fastapi>=0.75.2,<0.76.0',
 'pendulum>=2.1.2,<3.0.0',
 'poethepoet>=0.13.1,<0.14.0',
 'pydantic>=1.9.0,<2.0.0',
 'pytest-cov>=4.0.0,<5.0.0',
 'rm>=2020.12.3,<2021.0.0',
 'uvicorn[standard]>=0.20.0,<0.21.0']

setup_kwargs = {
    'name': 'updateservice',
    'version': '0.1.0',
    'description': 'Simple Python REST service to manage packages updates',
    'long_description': 'None',
    'author': 'Yuriy Senko',
    'author_email': 'ysenko@lohika.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
